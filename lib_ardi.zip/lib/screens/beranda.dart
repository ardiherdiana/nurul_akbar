import 'package:flutter/material.dart';
import 'package:nurul_akbar/components/navigation.dart';
import 'keuangan/keuangan.dart';
import 'acara.dart';
import 'pengurus.dart';
import 'profil.dart';
import 'package:intl/intl.dart';
import 'package:nurul_akbar/controllers/pemasukan_controller.dart';
import 'package:nurul_akbar/controllers/pengeluaran_controller.dart';
import 'package:fl_chart/fl_chart.dart';

enum ChartFilter { daily, weekly, monthly, yearly }

class BerandaScreen extends StatefulWidget {
  @override
  _BerandaState createState() => _BerandaState();
}

class _BerandaState extends State<BerandaScreen> {
  int _selectedIndex = 0;
  final PageController _pageController = PageController();
  final PemasukanController _pemasukanController = PemasukanController();
  final PengeluaranController _pengeluaranController = PengeluaranController();
  
  // Add these state variables
  ChartFilter _selectedChartFilter = ChartFilter.monthly;
  List<Map<String, dynamic>> _chartData = [];
  List<dynamic> _pemasukan = [];
  double _saldo = 0;
  double _pemasukanBulanIni = 0;
  double _pengeluaranBulanIni = 0;

  // Add this helper method
  double _getMaxAmount() {
    if (_chartData.isEmpty) return 1000;
    double maxAmount = _chartData.map((data) => data['amount'] as double).reduce((a, b) => a > b ? a : b);
    return maxAmount > 0 ? maxAmount : 1000; // Ensure we never return 0
  }

  @override
  void initState() {
    super.initState();
    _loadFinancialData();
  }

  Future<void> _loadFinancialData() async {
    try {
      final pemasukan = await _pemasukanController.fetchPemasukan();
      final pengeluaran = await _pengeluaranController.fetchPengeluaran();

      setState(() {
        _pemasukan = pemasukan;
      });

      // Calculate financial data
      final now = DateTime.now();
      final currentMonth = DateTime(now.year, now.month);

      double totalPemasukan = 0;
      double totalPemasukanBulanIni = 0;
      for (var p in pemasukan) {
        double jumlah = p.jumlah.toDouble();
        totalPemasukan += jumlah;
        
        final tanggal = DateTime.parse(p.tanggal);
        if (tanggal.year == currentMonth.year && tanggal.month == currentMonth.month) {
          totalPemasukanBulanIni += jumlah;
        }
      }

      double totalPengeluaran = 0;
      double totalPengeluaranBulanIni = 0;
      for (var p in pengeluaran) {
        double jumlah = p.jumlah.toDouble();
        totalPengeluaran += jumlah;
        
        final tanggal = DateTime.parse(p.tanggal);
        if (tanggal.year == currentMonth.year && tanggal.month == currentMonth.month) {
          totalPengeluaranBulanIni += jumlah;
        }
      }

      setState(() {
        _saldo = totalPemasukan - totalPengeluaran;
        _pemasukanBulanIni = totalPemasukanBulanIni;
        _pengeluaranBulanIni = totalPengeluaranBulanIni;
      });
    } catch (e) {
      print('Error loading financial data: $e');
    }
    _processChartData(); // Add this line to process chart data after loading
  }

  void _processChartData() {
    // Move the _processChartData method inside the class
    final now = DateTime.now();
    _chartData.clear();
    
    switch (_selectedChartFilter) {
      case ChartFilter.daily:
      // Last 7 days data
      for (int i = 6; i >= 0; i--) {
        final date = now.subtract(Duration(days: i));
        double dayTotal = 0;
        for (var p in _pemasukan) {
          final transaksiDate = DateTime.parse(p.tanggal);
          if (transaksiDate.year == date.year && 
                  transaksiDate.month == date.month && 
                  transaksiDate.day == date.day) {
            dayTotal += p.jumlah.toDouble();
          }
        }
        _chartData.add({
          'date': date,
          'amount': dayTotal,
        });
      }
      break;
      
      case ChartFilter.weekly:
      // Last 4 weeks data
      for (int i = 3; i >= 0; i--) {
        final weekStart = now.subtract(Duration(days: i * 7 + 7));
        final weekEnd = now.subtract(Duration(days: i * 7));
        double weekTotal = 0;
        for (var p in _pemasukan) {
          final transaksiDate = DateTime.parse(p.tanggal);
          if (transaksiDate.isAfter(weekStart) && 
                  transaksiDate.isBefore(weekEnd.add(Duration(days: 1)))) {
            weekTotal += p.jumlah.toDouble();
          }
        }
        _chartData.add({
          'date': weekStart,
          'amount': weekTotal,
        });
      }
      break;
      
      case ChartFilter.monthly:
      // Last 6 months data
      for (int i = 5; i >= 0; i--) {
        final month = DateTime(now.year, now.month - i);
        double monthTotal = 0;
        for (var p in _pemasukan) {
          final transaksiDate = DateTime.parse(p.tanggal);
          if (transaksiDate.year == month.year && 
                  transaksiDate.month == month.month) {
            monthTotal += p.jumlah.toDouble();
          }
        }
        _chartData.add({
          'date': month,
          'amount': monthTotal,
        });
      }
      break;
      
      case ChartFilter.yearly:
      // Last 3 years data
      for (int i = 2; i >= 0; i--) {
        final year = DateTime(now.year - i);
        double yearTotal = 0;
        for (var p in _pemasukan) {
          final transaksiDate = DateTime.parse(p.tanggal);
          if (transaksiDate.year == year.year) {
            yearTotal += p.jumlah.toDouble();
          }
        }
        _chartData.add({
          'date': year,
          'amount': yearTotal,
        });
      }
      break;
    }
    setState(() {});
  }

  // Fix the _onItemTapped method
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _pageController.animateToPage(
      index,
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  // Move _buildFinancialChart inside the class and fix its structure
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Masjid Jamie Nurul Akbar',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green,
      ),
      body: PageView(
        controller: _pageController,
        physics: NeverScrollableScrollPhysics(),
        children: [
          _buildMainContent(),
          KeuanganScreen(),
          AcaraScreen(),
          PengurusScreen(),
          ProfilScreen()
        ],
      ),
      bottomNavigationBar: Navigation(
        selectedIndex: _selectedIndex,
        onItemTapped: _onItemTapped,
      ),
    );
  }

  Widget _buildMainContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildUserProfile(),
          const SizedBox(height: 20),
          _buildSectionTitle("Ringkasan Keuangan Masjid", 1, Icons.edit),
          _buildFinancialSummary(),
          _buildSectionTitle("Ringkasan Acara Masjid", 2, Icons.edit),
          _buildEventSummary(),
          _buildSectionTitle("Ringkasan Kepengurusan Masjid", 3, Icons.edit),
          _buildManagementSummary(),
        ],
      ),
    );
  }

  Widget _buildUserProfile() {
    return Row(
      children: [
        const CircleAvatar(
          radius: 30,
          backgroundImage: AssetImage('assets/images/ardi-pm.png'),
        ),
        const SizedBox(width: 15),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              "Assalamu'alaikum, Ardi!",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text("Semoga harimu penuh berkah!", style: TextStyle(fontSize: 14)),
          ],
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title, int navIndex, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          IconButton(
            icon: Icon(icon, color: Colors.grey),
            onPressed: () {
              _onItemTapped(navIndex);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFinancialSummary() {
    final formatCurrency = NumberFormat("#,##0", "id_ID");
    
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Total Saldo",
            style: TextStyle(
              fontSize: 16,
              color: Colors.green.shade700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Rp ${formatCurrency.format(_saldo)}",
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.green.shade900,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.green.withOpacity(0.1),
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.arrow_upward, color: Colors.green, size: 20),
                          SizedBox(width: 8),
                          Text(
                            "Pemasukan",
                            style: TextStyle(
                              color: Colors.green.shade700,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        "Rp ${formatCurrency.format(_pemasukanBulanIni)}",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.green.shade900,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.green.withOpacity(0.1),
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.arrow_downward, color: Colors.red, size: 20),
                          SizedBox(width: 8),
                          Text(
                            "Pengeluaran",
                            style: TextStyle(
                              color: Colors.red.shade700,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        "Rp ${formatCurrency.format(_pengeluaranBulanIni)}",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.red.shade900,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFinancialChart() {
    return Container(
      margin: EdgeInsets.only(top: 20),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.green.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Statistik Keuangan',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: DropdownButton<ChartFilter>(
                  value: _selectedChartFilter,
                  underline: SizedBox(),
                  icon: Icon(Icons.keyboard_arrow_down, color: Colors.green),
                  items: ChartFilter.values.map((filter) {
                    String text = filter == ChartFilter.daily ? 'Harian' :
                               filter == ChartFilter.weekly ? 'Mingguan' :
                               filter == ChartFilter.monthly ? 'Bulanan' : 'Tahunan';
                    return DropdownMenuItem(
                      value: filter,
                      child: Text(text, style: TextStyle(color: Colors.green.shade700)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _selectedChartFilter = value;
                        _processChartData();
                      });
                    }
                  },
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: _chartData.isEmpty
                ? Center(
                    child: Text(
                      'Tidak ada data',
                      style: TextStyle(color: Colors.green.shade300),
                    ),
                  )
                : LineChart(
                    LineChartData(
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        getDrawingHorizontalLine: (value) {
                          return FlLine(
                            color: Colors.grey.withOpacity(0.05),
                            strokeWidth: 0.5,
                          );
                        },
                      ),
                      titlesData: FlTitlesData(
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 30,
                            interval: (_getMaxAmount() / 2),
                            getTitlesWidget: (value, meta) {
                              if (value == 0) return const Text('');
                              return Text(
                                NumberFormat.compact().format(value),
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.grey.shade400,
                                ),
                              );
                            },
                          ),
                        ),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 20,
                            getTitlesWidget: (value, meta) {
                              if (value >= 0 && value < _chartData.length) {
                                final date = _chartData[value.toInt()]['date'];
                                String text = _selectedChartFilter == ChartFilter.monthly 
                                    ? DateFormat('MMM').format(date)
                                    : DateFormat('d/M').format(date);
                                return Text(
                                  text,
                                  style: TextStyle(
                                    fontSize: 9,
                                    color: Colors.grey.shade400,
                                  ),
                                );
                              }
                              return const Text('');
                            },
                          ),
                        ),
                        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      minY: 0,
                      maxY: _getMaxAmount() * 1.1,
                      borderData: FlBorderData(show: false),
                      lineBarsData: [
                        LineChartBarData(
                          spots: _chartData.asMap().entries.map((entry) {
                            return FlSpot(entry.key.toDouble(), entry.value['amount']);
                          }).toList(),
                          isCurved: true,
                          gradient: LinearGradient(
                            colors: [Colors.green.shade300, Colors.green.shade400],
                          ),
                          barWidth: 2,
                          dotData: FlDotData(
                            show: true,
                            getDotPainter: (spot, percent, barData, index) {
                              return FlDotCirclePainter(
                                radius: 3,
                                color: Colors.white,
                                strokeWidth: 1.5,
                                strokeColor: Colors.green.shade400,
                              );
                            },
                          ),
                          belowBarData: BarAreaData(
                            show: true,
                            gradient: LinearGradient(
                              colors: [
                                Colors.green.shade100.withOpacity(0.2),
                                Colors.green.shade50.withOpacity(0.05),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventSummary() {
    return Card(
      elevation: 2,
      child: ListTile(
        leading: const Icon(Icons.calendar_today, color: Colors.green),
        title: const Text("Kajian Rutin"),
        subtitle: const Text("Jumat, 12:30 WIB"),
      ),
    );
  }

  Widget _buildManagementSummary() {
    return Card(
      elevation: 2,
      child: ListTile(
        leading: const Icon(Icons.people, color: Colors.green),
        title: const Text("Pengurus Masjid"),
        subtitle: const Text("Ketua: Ust. Ahmad | Bendahara: Pak Budi"),
      ),
    );
  }
}
