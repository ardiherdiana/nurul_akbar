import 'package:nurul_akbar/screens/beranda.dart';
import 'package:flutter/material.dart';
import 'package:nurul_akbar/screens/login.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nurul Akbar',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: Login(), // Set your home screen
    );
  }
}
