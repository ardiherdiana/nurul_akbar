List<Map<String, String>> dataKeuangan = [
  {
    'nama': 'Kas Masjid',
    'jumlah': 'Rp 500.000',
    'metode': 'Tunai',
    'tanggal': '12/03/2025'
  },
  {
    'nama': 'Pembelian Karpet',
    'jumlah': '-Rp 250.000',
    'metode': 'Transfer',
    'tanggal': '08/03/2025',
    'catatan': 'Untuk masjid'
  }
];

double getTotalPemasukan() {
  return dataKeuangan
      .where((item) => !item['jumlah']!.startsWith('-'))
      .map((item) =>
          double.parse(item['jumlah']!.replaceAll(RegExp(r'[^0-9]'), '')))
      .fold(0, (prev, amount) => prev + amount);
}

double getTotalPengeluaran() {
  return dataKeuangan
      .where((item) => item['jumlah']!.startsWith('-'))
      .map((item) =>
          double.parse(item['jumlah']!.replaceAll(RegExp(r'[^0-9]'), '')))
      .fold(0, (prev, amount) => prev + amount);
}
