import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'data_keuangan.dart';
import 'tambah_keuangan.dart';
import 'navigasi_keuangan.dart';
import 'navigasi_waktu_keuangan.dart';

class KeuanganScreen extends StatefulWidget {
  @override
  _KeuanganState createState() => _KeuanganState();
}

class _KeuanganState extends State<KeuanganScreen> {
  int _selectedTab = 0; // 0: Semua, 1: Pemasukan, 2: Pengeluaran
  int _selectedFilter =
      1; // 1: Semua, 2: Bulan Ini, 3: Bulan Lalu, 4: Minggu Ini, 5: Hari Ini
  DateTimeRange? _selectedDateRange;

  void _updateFilter(int filterIndex, DateTimeRange? range) {
    setState(() {
      _selectedFilter = filterIndex;
      _selectedDateRange = range;
    });
  }

  void _tambahKeuangan(Map<String, String> newData) {
    setState(() {
      dataKeuangan.add(newData);
    });
  }

  List<Map<String, String>> _getFilteredData() {
    List<Map<String, String>> filteredData = dataKeuangan;

    if (_selectedTab == 1) {
      filteredData = filteredData
          .where((item) => !item['jumlah']!.startsWith('-'))
          .toList();
    } else if (_selectedTab == 2) {
      filteredData = filteredData
          .where((item) => item['jumlah']!.startsWith('-'))
          .toList();
    }

    DateTime now = DateTime.now();
    DateTime startOfMonth = DateTime(now.year, now.month, 1);
    DateTime startOfLastMonth = DateTime(now.year, now.month - 1, 1);
    DateTime endOfLastMonth = DateTime(now.year, now.month, 0);
    DateTime startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    DateTime startOfDay = DateTime(now.year, now.month, now.day);

    if (_selectedFilter == 2) {
      filteredData = filteredData.where((item) {
        DateTime date = DateFormat('dd/MM/yyyy').parse(item['tanggal']!);
        return date.isAfter(startOfMonth) ||
            date.isAtSameMomentAs(startOfMonth);
      }).toList();
    } else if (_selectedFilter == 3) {
      filteredData = filteredData.where((item) {
        DateTime date = DateFormat('dd/MM/yyyy').parse(item['tanggal']!);
        return date.isAfter(startOfLastMonth) && date.isBefore(endOfLastMonth);
      }).toList();
    } else if (_selectedFilter == 4) {
      filteredData = filteredData.where((item) {
        DateTime date = DateFormat('dd/MM/yyyy').parse(item['tanggal']!);
        return date.isAfter(startOfWeek) || date.isAtSameMomentAs(startOfWeek);
      }).toList();
    } else if (_selectedFilter == 5) {
      filteredData = filteredData.where((item) {
        DateTime date = DateFormat('dd/MM/yyyy').parse(item['tanggal']!);
        return date.isAtSameMomentAs(startOfDay);
      }).toList();
    } else if (_selectedFilter == 0 && _selectedDateRange != null) {
      filteredData = filteredData.where((item) {
        DateTime date = DateFormat('dd/MM/yyyy').parse(item['tanggal']!);
        return date.isAfter(_selectedDateRange!.start) &&
            date.isBefore(_selectedDateRange!.end.add(Duration(days: 1)));
      }).toList();
    }

    return filteredData;
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, String>> filteredData = _getFilteredData();

    return Scaffold(
      body: Column(
        children: [
          NavigasiKeuangan(
            selectedTab: _selectedTab,
            onTabChanged: (index) {
              setState(() {
                _selectedTab = index;
              });
            },
          ),
          NavigasiWaktuKeuangan(
            selectedFilter: _selectedFilter,
            selectedRange: _selectedDateRange,
            onFilterChanged: _updateFilter,
          ),
          Expanded(
            child: filteredData.isEmpty
                ? Center(
                    child: Text(
                      "Data tidak ada",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: filteredData.length,
                    itemBuilder: (context, index) {
                      final data = filteredData[index];
                      return Card(
                        margin: EdgeInsets.all(8),
                        child: ListTile(
                          leading: Icon(
                            data['jumlah']!.startsWith('-')
                                ? Icons.arrow_upward
                                : Icons.arrow_downward,
                            color: data['jumlah']!.startsWith('-')
                                ? Colors.red
                                : Colors.green,
                          ),
                          title: Text(data['nama']!),
                          subtitle:
                              Text("${data['tanggal']} • ${data['metode']}"),
                          trailing: Text(
                            data['jumlah']!,
                            style: TextStyle(
                              color: data['jumlah']!.startsWith('-')
                                  ? Colors.red
                                  : Colors.green,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showDialog(
          context: context,
          builder: (context) => TambahKeuanganDialog(onTambah: _tambahKeuangan),
        ),
        child: Icon(Icons.add, color: Colors.white),
        backgroundColor: Colors.green,
      ),
    );
  }
}
