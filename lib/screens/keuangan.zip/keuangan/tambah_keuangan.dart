import 'package:flutter/material.dart';

class TambahKeuanganDialog extends StatefulWidget {
  final Function(Map<String, String>) onTambah;

  TambahKeuanganDialog({required this.onTambah});

  @override
  _TambahKeuanganDialogState createState() => _TambahKeuanganDialogState();
}

class _TambahKeuanganDialogState extends State<TambahKeuanganDialog> {
  TextEditingController namaController = TextEditingController();
  TextEditingController jumlahController = TextEditingController();
  TextEditingController tanggalController = TextEditingController();
  TextEditingController catatanController = TextEditingController();
  String? metodePembayaran;
  String? jenisPemasukan;

  Future<void> _selectDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
    setState(() {
      tanggalController.text =
          "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
    });
  }
  }

  String _getMonthName(int month) {
    const monthNames = [
      "Januari",
      "Februari",
      "Maret",
      "April",
      "Mei",
      "Juni",
      "Juli",
      "Agustus",
      "September",
      "Oktober",
      "November",
      "Desember"
    ];
    return monthNames[month - 1];
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Tambah Data Keuangan"),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: namaController,
              decoration: InputDecoration(labelText: "Nama"),
            ),
            TextField(
              controller: jumlahController,
              decoration: InputDecoration(labelText: "Jumlah (Rp)"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: tanggalController,
              decoration: InputDecoration(labelText: "Tanggal"),
              readOnly: true,
              onTap: _selectDate,
            ),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(labelText: "Metode Pembayaran"),
              value: metodePembayaran,
              items: ["QRIS", "Transfer Bank", "Offline"]
                  .map((String item) => DropdownMenuItem<String>(
                        value: item,
                        child: Text(item),
                      ))
                  .toList(),
              onChanged: (String? newValue) {
                setState(() {
                  metodePembayaran = newValue;
                });
              },
            ),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(labelText: "Jenis Pemasukan"),
              value: jenisPemasukan,
              items: ["Zakat", "Sedekah", "Donasi"]
                  .map((String item) => DropdownMenuItem<String>(
                        value: item,
                        child: Text(item),
                      ))
                  .toList(),
              onChanged: (String? newValue) {
                setState(() {
                  jenisPemasukan = newValue;
                });
              },
            ),
            TextField(
              controller: catatanController,
              decoration: InputDecoration(labelText: "Catatan"),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text("Batal", style: TextStyle(color: Colors.green)),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          onPressed: () {
            widget.onTambah({
              'nama': namaController.text,
              'jumlah': jumlahController.text,
              'metode': metodePembayaran ?? "-",
              'tanggal': tanggalController.text,
              'catatan': catatanController.text,
            });
            Navigator.pop(context);
          },
          child: Text("Simpan", style: TextStyle(color: Colors.white)),
        ),
      ],
    );
  }
}
